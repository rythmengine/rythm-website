package com.greenlaw110.rythm.sample;

import com.greenlaw110.rythm.Rythm;

/**
 * A Hello world sample
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println(Rythm.render("hello @who!", "rythm"));
    }
}
