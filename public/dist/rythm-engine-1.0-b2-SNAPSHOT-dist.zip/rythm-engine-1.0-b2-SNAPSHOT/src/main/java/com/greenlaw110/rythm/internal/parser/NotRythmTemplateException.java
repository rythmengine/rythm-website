package com.greenlaw110.rythm.internal.parser;

/**
 * Created by IntelliJ IDEA.
 * User: luog
 * Date: 27/01/12
 * Time: 7:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class NotRythmTemplateException extends RuntimeException {
    private static final long serialVersionUID = 1L;
}
