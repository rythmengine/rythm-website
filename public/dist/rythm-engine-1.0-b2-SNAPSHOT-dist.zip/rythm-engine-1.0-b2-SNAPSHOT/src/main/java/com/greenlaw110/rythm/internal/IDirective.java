package com.greenlaw110.rythm.internal;

/**
 * Mark a token 
 */
public interface IDirective {
    void call();
}
