package com.greenlaw110.rythm.utils;

import com.greenlaw110.rythm.template.ITemplate;

/**
 * Created by IntelliJ IDEA.
 * User: luog
 * Date: 25/01/12
 * Time: 12:36 PM
 * To change this template use File | Settings | File Templates.
 */
public interface IRythmListener {
    void onRender(ITemplate template);
}
