package com.greenlaw110.rythm.internal.dialect;

import com.greenlaw110.rythm.spi.IDialect;

public abstract class Razor implements IDialect {
    
    public static IDialect INSTANCE ;//= new Razor();

}
