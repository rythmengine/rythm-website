package com.greenlaw110.rythm.internal.dialect;

public abstract class Japid extends Razor {
}
