package com.greenlaw110.rythm.utils;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: luog
 * Date: 20/08/12
 * Time: 5:55 AM
 * To change this template use File | Settings | File Templates.
 */
public interface IImportProvider {
    List<String> imports();
}
