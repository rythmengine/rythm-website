package com.greenlaw110.rythm.exception;

/**
 * Created with IntelliJ IDEA.
 * User: luog
 * Date: 3/04/12
 * Time: 6:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class TagLoadException extends FastRuntimeException {
    public TagLoadException(Throwable t) {
        super(t);
    }
}
