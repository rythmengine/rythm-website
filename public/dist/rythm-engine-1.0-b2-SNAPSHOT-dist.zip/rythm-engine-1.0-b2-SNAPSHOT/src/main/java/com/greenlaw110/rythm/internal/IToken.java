package com.greenlaw110.rythm.internal;

public interface IToken {

}
