package com.greenlaw110.rythm.spi;

/**
 * Created by IntelliJ IDEA.
 * User: luog
 * Date: 29/01/12
 * Time: 11:24 AM
 * To change this template use File | Settings | File Templates.
 */
public interface IKeywordParserFactory extends IParserFactory {
    IKeyword keyword();
}
