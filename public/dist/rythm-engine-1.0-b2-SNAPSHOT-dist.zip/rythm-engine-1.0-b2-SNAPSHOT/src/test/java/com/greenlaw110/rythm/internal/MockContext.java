package com.greenlaw110.rythm.internal;

public class MockContext extends TemplateParser {

    public MockContext(CodeBuilder cb) {
        super(cb);
    }

}
