package com.greenlaw110.rythm.ut;

import com.greenlaw110.rythm.internal.MockCodeBuilder;
import com.greenlaw110.rythm.internal.MockContext;
import com.greenlaw110.rythm.internal.dialect.DialectBase;
import com.greenlaw110.rythm.internal.dialect.Rythm;
import com.greenlaw110.rythm.internal.parser.Directive;
import com.greenlaw110.rythm.utils.TextBuilder;

public class UnitTest extends org.junit.Assert {
    
    protected DialectBase d = (DialectBase)Rythm.INSTANCE;
    protected MockContext c;
    protected MockCodeBuilder b;
    
    protected void setup(String template) {
        b = new MockCodeBuilder(template, "test", null);
        c = new MockContext(b);
    }
    
    protected void call(TextBuilder b) {
        if (b instanceof Directive) {
            ((Directive)b).call();
        }
    }
    
}
